﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TiliToli
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int lepesekszama = 0;
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Button egyikGomb = sender as Button;
            Button nullaGomb = (Button)FindName("Button0");
            int vTav = Math.Abs((int)(egyikGomb.Margin.Left - nullaGomb.Margin.Left));
            int fTav = Math.Abs((int)(egyikGomb.Margin.Top - nullaGomb.Margin.Top));
            if ((vTav <120 && fTav == 0) || (fTav < 120 && vTav == 0)) {
                var seged = egyikGomb.Margin;
                egyikGomb.Margin = nullaGomb.Margin;
                nullaGomb.Margin = seged;
            }
        }

        lepesszam.Content = "Lépésszám: ";
        Button nullGomb = (Button)FindName("Button0");
        Random r = new Random();

        private void ujjatek_Click(object sender, RoutedEventArgs e)
        {
            keveres();
        }
        public void keveres()
        {
            lepesekszama = 0;
            int random = 0;
            int r = 0;
            lepesszam.Content = "Lépések száma: " + lepesekszama;
            Button nullGomb = (Button)FindName("Button0");
            do
            {

                string Button = "Button" + random;
                Button RandomButton = (Button)FindName(Button);
                int vtav = Math.Abs((int)(RandomButton.Margin.Left - nullGomb.Margin.Left));
                int ftav = Math.Abs((int)(RandomButton.Margin.Top - nullGomb.Margin.Top));
                if ((vtav < 130 && ftav == 0) || (ftav < 130 && vtav == 0))

                {
                    var seged = RandomButton.Margin;
                    RandomButton.Margin = nullGomb.Margin;
                    nullGomb.Margin = seged;
                    r++;
                }

            } while (r != Shuffle);
        }
    }
}
